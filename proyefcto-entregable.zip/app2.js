$(".navegacion").on("click", ()=>{
   $(".nav__menu__desplegable").toggle("slow")})